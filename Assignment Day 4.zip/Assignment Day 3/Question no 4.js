let survey=[{
    name:"Athira",
    age:"23",
    country:"India",
    hobbies:["reading","singing","badminton"]
},{
    name:"Anamika",
    age:"18",
    country:"India",
    hobbies:["dancing","volleyball","reading"]
},{
    name:"Fred",
    age:"35",
    country:"Australlia",
    hobbies:["Football","Cricket","Watching movies"]
}];
function ab_1()
{
    for(let i=0;i<survey.length;i++)
    {
        if(survey[i].age<30)
        {
            const element=survey[i];
            console.log(`Name:${element.name}
            age:${element.age}
            country:${element.country}
            hobbies:${element.hobbies}`);
        }
    }
}
function ab_2()
{
    for(let i=0;i<survey.length;i++){
        if(survey[i].country=="India"){
            const element=survey[i];
            console.log(`Name:${element.name}
            age:${element.age}
            country:${element.country}
            hobbies:${element.hobbies}`);

        }
    }
}
display(survey);