//program to display only elements containing 'a' in them from a array
let x=["Vanilla","Strawberry","Coconut","Chocolate","Butterscotch"]
let a;
for(let i=0;i<x.length;i++)
{
    a=x[i].search('a');
    if(a>0)
    {
        console.log(x[i]);
    }
}