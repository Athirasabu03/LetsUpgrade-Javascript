function button_1 ()
{
    document.getElementById("img1").src="image1.jpg";
}
function button_2()
{
    document.getElementById("img2").src="image2.jpg";
}
function button_3()
{
    document.getElementById("img3").src="image3.jpg";
}
