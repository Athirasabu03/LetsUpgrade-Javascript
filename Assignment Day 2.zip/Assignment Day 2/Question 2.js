//program to convert minutes to seconds
let m=prompt("Enter the minutes: ");
let s=m*60;
console.log(s);//where s is seconds
