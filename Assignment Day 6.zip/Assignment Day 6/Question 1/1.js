let survey=[
    {
        name:"Reshma",
        age:27,
        city:"Chennai",
        salary:30000
    },
    {
        name:"Thomas",
        age:32,
        city:"Trivandrum",
        salary:40000
    },
    {
        name:"Priya",
        age:23,
        city:"Hyderabad",
        salary:20000
    },
    {
        name:"Anand",
        age:25,
        city:"Mumbai",
        salary:50000
    },
    {
        name:"Ayurvati",
        age:30,
        city:"Punjab",
        salary:45000
    }};
]
function searchName(){
    let searchValue=document.getElementById("searchName").value}
    console.log(searchValue);
function searchCity(){
    let searchValue1=document.getElementById("searchName").value}
        console.log(searchValue1);