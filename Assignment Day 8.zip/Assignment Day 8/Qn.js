let products = [
    {
      id: 1,
      name: "White Tshirt",
      size: "L",
      color: "white",
      price: 1200,
      image: "Product1.jpg",
      description: "Good looking white tshirt",
    },
    {
      id: 2,
      name: "Black Shirt",
      size: "M",
      color: "Black",
      price: 1500,
      image: "Product2.jpg",
      description: "Good looking black shirt",
    },
  
    {
      id: 3,
      name: "Checked Shirt",
      size: "S",
      color: "White & Blue",
      price: 900,
      image: "Product3.jpg",
      description: "Good looking Checked Shirt",
    },
  
    {
      id: 4,
      name: "Black Female Blazer",
      size: "M",
      color: "Black",
      price: 3000,
      image: "Product4.jpg",
      description: "Beautifull Blazer",
    },
  
    {
      id: 5,
      name: "Navy Blue Top",
      size: "S",
      color: "Blue",
      price: 1300,
      image: "Product5.jpg",
      description: "Good looking Top",
    },
  
    {
      id: 6,
      name: "Indian Dress",
      size: "M",
      color: "Black with Golden Border",
      price: 1500,
      image: "Product6.jpg",
      description: "Good looking Traditional Dress",
    },

    {
      id:7,
      name: "Dhawani",
      size: "M",
      color: "Orange and Yellow",
      price: 3000,
      image: "Product7.jpg",
      description: "Pretty looking Traditional Dress",
    },
    {
      id: 8,
      name:"Set Saree",
      size: "M",
      color: "White with Green Design",
      price: 2000,
      image: "Product8.jpg",
      description: "Traditional wear of Kerala",
    },
    {
      id: 9,
      name: "Lehanga",
      size: "L",
      color: "Pink",
      price: 1500,
      image: "Product9.jpg",
      description: " Fantastic Party wear",
    },
    {
      id: 10,
      name: "Churidar",
      size: "S",
      color: "Dark Blue",
      price: 1500,
      image: "Product10.jpg",
      description: "A traditional Party wear",
    },
    {
      id: 11,
      name: "Formal wear for women",
      size: "M",
      color: "Black ",
      price: 1000,
      image: "Product11.jpg",
      description: "A formal office wear excusively for professional women",
    },
    {
      id: 12,
      name: "Formal wear for men",
      size: "XL",
      color: "Navy Blue",
      price: 2500,
      image: "Product12.jpg",
      description: "A formal office wear excusively for professional men",
    }
    
  ];
  
  cart=[];
  function displayProducts(productsData)
  {
     let productsString="";

     productsData.forEach(function (product) {
       let {name,image,color,description,price,size}=product;
      productsString+=`<div class="product">
      <div class="prodimg">
        <img src="E:\NOTES\Javascript\project images\ ${product.image}" width="100%"/>
      </div>
      <h3>${name}</h3>
      <p>Price:${price}</p>
      <p>Size:${size}</p>
      <p>Color:${color}</p>
      <p>${description}</p>
      <p>
        <button onclick="addToCart(${product})">Add to Cart</button>
      </p>
     </div>`
       
     });

     document.getElementById("productwrapper").innerHTML=productsString;
  }
  displayProducts();


  function searchProduct(searchValue){
    let searchedProducts=products.filter(function (product,index) {
      let searchString =
      product.name + " " + product.color + " " + product.description;
    
      return searchString.toUpperCase().indexOf(searchValue.toUpperCase()) != -1;
      if(location.SearchedProduct=="cart")
      {
        console.log("The product is already in cart");
      }
    })

    displayProducts(searchedProducts);
  }

  function addToCart(product){
    cart.push(product);
    console.log(cart);
  }
   
  let counter=0;
  function addToCart() {
    console.log(counter);
    counter++;

    
    
  }