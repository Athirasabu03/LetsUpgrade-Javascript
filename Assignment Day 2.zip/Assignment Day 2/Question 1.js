//program to search for a particular character in a string
let name=prompt("Please enter your name: ");
let alp=prompt("Enter the character to be searched: ");
let index=name.indexOf(alp);
console.log(index);