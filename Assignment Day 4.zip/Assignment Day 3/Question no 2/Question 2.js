function click()
{
    let input1=document.getElementsByTagName("input").input1.value;
    document.getElementsByTagName("input").input2.value=input1;
}