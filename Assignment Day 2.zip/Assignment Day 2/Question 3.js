//program to search for an element in array of strings
let data=["Apple","Mango","Strawberry","Watermelon","Pineapple"];
let ele=prompt("Enter the element to be searched from the given array: ");
let index=data.indexOf(ele);
console.log(index);