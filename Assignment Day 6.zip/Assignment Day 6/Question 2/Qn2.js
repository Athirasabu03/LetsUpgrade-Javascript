window.onload=function(){


let initialArray=[{
    name:" ",
    source:" ",
    destination:" ",
    number:" ",
    passenger capacity:" ",
    
},{
name:" ",
source:" ",
destination:" ",
number:" ",
passenger capacity:" ",
},{
name:" ",
source:" ",
destination:" ",
number:" ",
passenger capacity:" ",
};
if (localStorage.getItem("Bus") == null) {
    localStorage.setItem("Bus", JSON.stringify(initialArray));
  }
};
function display(superarray = undefined) {
    let tabledata = "";
    let Bus;
    if (superarray == undefined) {
      Bus = JSON.parse(localStorage.getItem("addNewBus"));
    } else {
      Bus = superarray;
    }
    Bus.forEach(function (Bus, index) {
        let currentrow = `<tr>
          <td>${index + 1}</td>
          <td>${Bus.name}</td>
          <td>${Bus.source}</td>
          <td>${Bus.destination}</td>
          <td>${Bus.number}</td>
          <td>${Bus.passengerCapacity}</td>
          
          </tr>`;
    
        tabledata += currentrow;
      });
    
      document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
     
    }
    
    display();
    function addNewBus(e) {
        e.preventDefault();
        let Bus = {};
        let name = document.getElementById("name").value;
        let source = document.getElementById("source").value;
        let destination = document.getElementById("destination").value;
        let number = document.getElementById("number").value;
        let passengerCapacity = document.getElementById("passengerCapacity").value;
        Bus.name = name;
        Bus.source = source;
        Bus.destination = destination;
        Bus.number = number;
        Bus.passengerCapacity = passengerCapacity;
    }
    let Bus = JSON.parse(localStorage.getItem("bus"));
  superheroes.push(Bus);
  localStorage.setItem("Bus", JSON.stringify(Bus));

  display();

  document.getElementById("name").value = "";
  document.getElementById("source").value = "";
  document.getElementById("destination").value = "";
  document.getElementById("number").value = "";
  document.getElementById("passengerCapacity").value = "";
}
        function searchBySource() {
            let searchValue = document.getElementById("searchName").value;
            let Bus = JSON.parse(localStorage.getItem("Source"));
            let newdata = Bus.filter(function (destination) {
              return (
            Bus.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
              );
              function searchByDestination() {
                let searchValue = document.getElementById("searchName").value;
                let Bus = JSON.parse(localStorage.getItem("Destination"));
                let newdata = Bus.filter(function (destination) {
                  return (
                    Bus.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
                  );
      display(newdata);
