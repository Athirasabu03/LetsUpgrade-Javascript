//program to print an array in reverse order
let x=["Red","Orange","Green","Blue","Yellow"];
console.log("Array before reversing: ");
console.log(x);
console.log("Array after reversing: ");
console.log(x.reverse());